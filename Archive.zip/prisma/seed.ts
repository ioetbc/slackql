import {PrismaClient} from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  const connections = [
    {
      teamId: "T05107E12TA",
      connectionString:
        "c13eaba4570c28c8ea52d38c637d1404fb13fd0c8337d852ccc6682004b25a59abcd9dcef6c60b5db5dfd9499dbfe251fa515e4811ebfcf79c2dee1dfb76a2eb",
      openAI:
        "70d9575f11fee0de3520cc3f3f3bd4227677242cd27000d43472e27f2b3a28f405b51739d28bd9a619b7e289eaa9629175df468a38218bd74542f368af4a41c9",
    },
  ];

  const users = [
    {
      username: "ioetbc",
      email: "ioetbc@gmail.com",
      purchaseDate: new Date(),
      favouriteColor: "blue",
    },
    {
      username: "bob",
      email: "bob@gmail.com",
      purchaseDate: new Date(),
      favouriteColor: "red",
    },
    {
      username: "carol",
      email: "carol@gmail.com",
      purchaseDate: new Date(),
      favouriteColor: "red",
    },
  ];

  for (const connection of connections) {
    await prisma.connection.create({
      data: connection,
    });
  }

  for (const user of users) {
    await prisma.user.create({
      data: user,
    });
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
